# Full Stack URL Shortener with React JS, Tailwind CSS, Supabase, Shadcn UI Tutorial 🔥🔥
## https://youtu.be/geIwBIuo-ug
![url shortener 4](https://github.com/piyush-eon/url-shortener/assets/51760520/dc91a72a-6a96-4cbe-a58c-15c6986d3740)
